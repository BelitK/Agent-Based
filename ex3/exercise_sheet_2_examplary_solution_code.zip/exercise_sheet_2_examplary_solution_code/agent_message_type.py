from dataclasses import dataclass
from typing import Set

from mango import AgentAddress

@dataclass
class NeighborhoodInformation:
    neighbors: Set[AgentAddress]


class GreetNeighbor:
    pass