import asyncio

from mango import create_tcp_container, activate

from SimpleAgent import SimpleAgent
from TopoAgent import TopoAgent

CONTAINER_ADDRESS = ('localhost', 5555)
N_AGENTS = 10
K = 1
RANDOMIZE = 0
PLOT_TOPO = True


async def main():
    container = create_tcp_container(addr=CONTAINER_ADDRESS)
    agent_addresses = {}
    agents = []
    # create num_agents agents of class SimpleAgent
    for i in range(N_AGENTS):
        agent = container.register(SimpleAgent(), suggested_aid=f"SimpleAgent{i}")
        agents.append(agent)
        agent_addresses[agent.aid] = agent.addr

    # create Topology Agent and set agent_adresses.
    topo_agent = container.register(TopoAgent(agents=agent_addresses,
                           plot_topo=PLOT_TOPO),
                           suggested_aid="TopoAgent")

    async with activate(container):
        # run TopoAgent -> creating topology.
        await topo_agent.run(k=K, randomize=RANDOMIZE)

        # wait until all agents are done!
        futs = [agent.all_msg_received for agent in agents]
        await asyncio.gather(*futs)

        # print final connection infos
        for agent in agents:
            agent.print_connection_info()


if __name__ == "__main__":
    asyncio.run(main())
