import random
from typing import Dict, Any, List

import matplotlib.pyplot as plt
import networkx as nx
from mango import Agent, AgentAddress
from agent_message_type import NeighborhoodInformation


class TopoAgent(Agent):
    def __init__(self, agents: Dict[str, AgentAddress], plot_topo=False):
        super().__init__()
        self._known_agents: Dict[str, AgentAddress] = agents
        self._connections: Dict[str, List[AgentAddress]] = {}
        self._plot_topo = plot_topo

        # Setup Topology Graph
        self.__topology_graph = nx.DiGraph()
        for node in range(0, len(agents)):
            self.__topology_graph.add_node(node)

    async def run(self, k=1, randomize=0):
        """
        Let the TopoAgent run - i.e. creating a topology and informing agents about their neighborhood.
        :param k: Count of connections. k=1 equals Ring and adds neighbors left and right.
        :param randomize: > 0 means randomized connections are added. 1.0 = fully connected.
        """
        if k > len(self._known_agents):
            raise Exception("k is to large!")

        self._create_topology(k=k, randomize=randomize)
        await self._inform_agents_about_neighbors()

    async def _inform_agents_about_neighbors(self):
        """
        Inform each agent from known_agents about its neighbors.
        """
        for agent in self._known_agents:
            agent_addr = self._known_agents[agent]
            content = NeighborhoodInformation(
                neighbors=set(self._connections[agent]))
            await self.send_message(content, agent_addr)

    def _create_topology(self, k, randomize):
        """
        Creates a topology by given k and random factor.
        :param k: Amount of neighbors for each agent.
        :param randomize: Randomize factor if a randomized connection should be added.
        """
        self._say(
            f'Create Topology with k={k} and random={randomize} for n={len(self._known_agents)} Agents')

        # Create connections for all known agents by given k
        for agent_number, current_aid in enumerate(self._known_agents.keys()):
            self._connections[current_aid] = []
            self._create_connections_for_agent(agent_number, current_aid, k)

        # Add random connections for agents by given random factor
        for agent_number, current_aid in enumerate(self._known_agents.keys()):
            self._create_random_connections_for_agent(
                agent_number, current_aid, k, randomize)

        if self._plot_topo:
            self.plot_topology(k, randomize)

    def _create_connections_for_agent(self, agent_number, current_aid, k):
        """
        Create connections for an specific agent with given k
        :param agent_number: Number of agent in List.
        :param current_aid: Current Agent ID
        :param k: Num of Connections of agent.
        """
        for i in range(k):
            # add agent i + 1 and agent i - 1 as neighbors.
            left_idx = agent_number - (i + 1)
            right_idx = (agent_number + (i + 1)
                         ) % len(self._known_agents.keys())
            left_key = list(self._known_agents)[left_idx]
            right_key = list(self._known_agents)[right_idx]
            left_addr = self._known_agents[left_key]
            right_addr = self._known_agents[right_key]
            self._connections[current_aid].append(left_addr)
            self._connections[current_aid].append(right_addr)

            # add new connections to graph
            self.__topology_graph.add_edge(agent_number, int(
                left_key[-1]), color='black', weight=1)

    def _create_random_connections_for_agent(self, agent_number, current_aid, k, random_factor=0.0):
        """
        Create random connections for an specific agent by given random factor.
        :param agent_number: Number of agent in List.
        :param current_aid: Current Agent ID
        :param k: Num of Connections of agent.
        :param random_factor: Factor for probability. 1.0 = fully connected.
        """
        # determine possible connections.
        possible_edges = range(
            min(len(self._known_agents.keys()), k + 1), len(self._known_agents.keys()) - k)

        for j in possible_edges:
            # Determine random connections with a random factor
            if random.random() < random_factor:
                left_idx = agent_number - (j + 1)
                right_idx = (agent_number + (j + 1)
                             ) % len(self._known_agents.keys())
                left_key = list(self._known_agents)[left_idx]
                right_key = list(self._known_agents)[right_idx]
                left_addr = self._known_agents[left_key]
                right_addr = self._known_agents[right_key]
                self._connections[current_aid].append(left_addr)
                self._connections[current_aid].append(right_addr)
                self._connections[left_key].append(
                    self._known_agents[current_aid])
                self._connections[right_key].append(
                    self._known_agents[current_aid])

                # add edges to topology graph
                self.__topology_graph.add_edge(
                    agent_number, int(left_key[-1]), color='r', weight=1)
                self.__topology_graph.add_edge(
                    agent_number, int(right_key[-1]), color='r', weight=1)

    def _say(self, content):
        """
        Helper function to print per agent.
        :param content: Message to be printed.
        """
        CGREEN = '\33[32m'
        CEND = '\033[0m\n'
        print(f'{CGREEN}[{self.aid}] {content}{CEND}')

    def plot_topology(self, k, randomize):
        """
        Plot topology after creation.
        :param k: -
        :param randomize: -
        """
        # plot topology after it was created!
        plt.figure(figsize=(15, 10))
        ax = plt.gca()
        ax.set_title(
            f'Topology with k={k} and randomize={randomize}', fontsize=30)
        pos = nx.circular_layout(self.__topology_graph)
        edges = self.__topology_graph.edges()
        colors = [self.__topology_graph[u][v]['color'] for u, v in edges]
        weights = [self.__topology_graph[u][v]['weight'] for u, v in edges]
        nx.draw_networkx(self.__topology_graph, pos, edge_color=colors,
                width=weights, with_labels=True)
        plt.draw()
        plt.savefig("topology.pdf")
