import asyncio
from typing import Any
from mango import Agent, AgentAddress, sender_addr

from agent_message_type import GreetNeighbor, NeighborhoodInformation


class SimpleAgent(Agent):
    def __init__(self):
        super().__init__()
        self._received_ids: set[AgentAddress] = set()
        self._neighbors: set[AgentAddress] = set()
        self.all_msg_received = asyncio.Future()

    def handle_message(self, content, meta: dict[str, Any]):
        """
        Handle Message methods - has to be overwritten from mango.core.agent.Agent
        :param content: Message Content
        :param meta: ACL Meta information of message
        """
        self._say(f"Received message from {meta.get('sender_id', None)}!")
        if isinstance(content, NeighborhoodInformation):
            self._neighbors = content.neighbors
            self.schedule_instant_task(self._greet_neighbors())
        elif isinstance(content, GreetNeighbor):
            self._received_ids.add(sender_addr(meta))
            # received all information of my neighbors
            if self._neighbors == self._received_ids:
                self._say('Received all awaited messages!', style='\033[91m')
                self.all_msg_received.set_result(True)
        else:
            self._say('Unsupported Performative!')

    async def _greet_neighbors(self):
        """
        Send greetings to neighbors.
        """
        for addr in self._neighbors:
            content = GreetNeighbor()
            await self.schedule_instant_message(content, addr)

    def _say(self, content, style='\33[33m'):
        """
        Helper function to print per agent.
        :param content: Message to be printed.
        """
        CEND = '\033[0m'
        print(f'{style}[{self.aid}] {content}{CEND}')

    def print_connection_info(self):
        """
        Print Agent Infos.
        """
        self._say(f'Received IDs: {self._received_ids}', style="\33[100m")
        self._say(f'Received Neighbors: {self._neighbors}', style="\33[100m")
